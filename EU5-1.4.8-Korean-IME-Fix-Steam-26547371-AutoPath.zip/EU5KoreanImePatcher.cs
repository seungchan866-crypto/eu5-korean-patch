using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

internal static class EU5KoreanImePatcher
{
    private const string AppId = "3450310";
    private const string AppManifest = "appmanifest_" + AppId + ".acf";
    private const string GameExecutable = @"binaries\eu5.exe";
    private const string Build = "26547371";
    private const string Branch = "1.4.8-testing-branch";
    private const long ExeLength = 272255608;
    private const long Offset = 12500561;
    private const string OriginalHash = "650c922ea6275d90ca960c6fc8821aa7fe7e7d22b893180277e7f1d7746384d5";
    private const string PatchedHash = "cc33bc1abde35ce58dd520887b6f05461f668aa09ab740934e0f8d998762e22a";
    private static readonly byte[] OriginalBytes = { 0x0F, 0x84, 0x19, 0xFB, 0xFF, 0xFF };
    private static readonly byte[] PatchedBytes = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };

    private static int Main(string[] args)
    {
        Console.OutputEncoding = new UTF8Encoding(false);
        bool interactive = args.Length == 0 && !Console.IsInputRedirected;
        try
        {
            string mode = args.Length == 0 ? "status" : args[0].ToLowerInvariant();
            if (mode == "--help" || mode == "-h")
            {
                PrintUsage();
                return 0;
            }
            if ((args.Length != 0 && args.Length != 1 && args.Length != 3) ||
                (args.Length == 3 && args[1] != "--game-dir") ||
                (mode != "status" && mode != "apply" && mode != "restore"))
            {
                PrintUsage();
                return 2;
            }

            string root = args.Length == 3 ? Path.GetFullPath(args[2]) : ResolveGameRoot(GetSteamRoots(), interactive);
            if (interactive)
            {
                Run("status", root);
                Console.WriteLine("1. 한글 입력 패치 적용   2. 원본 실행 파일 복원   Enter. 종료");
                Console.Write("> ");
                string choice = Console.ReadLine();
                if (choice == "1" || choice == "2")
                    Run(choice == "1" ? "apply" : "restore", root);
            }
            else
            {
                Run(mode, root);
            }
            return 0;
        }
        catch (UnauthorizedAccessException error)
        {
            Console.Error.WriteLine("접근 권한이 부족합니다. 적용·복원은 관리자 PowerShell에서 다시 실행할 수 있습니다.");
            Console.Error.WriteLine(error.Message);
            return 1;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine(error.Message);
            return 1;
        }
        finally
        {
            if (interactive)
            {
                Console.WriteLine("Enter를 누르면 창을 닫습니다.");
                Console.ReadLine();
            }
        }
    }

    private static void PrintUsage()
    {
        Console.WriteLine("EU5-Korean-IME-Patcher.exe status|apply|restore [--game-dir <설치 폴더>]");
    }

    private static IEnumerable<string> GetSteamRoots()
    {
        return new[]
        {
            ReadRegistryPath(RegistryHive.CurrentUser, RegistryView.Default, "SteamPath"),
            ReadRegistryPath(RegistryHive.LocalMachine, RegistryView.Registry32, "InstallPath"),
            ReadRegistryPath(RegistryHive.LocalMachine, RegistryView.Registry64, "InstallPath"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Steam")
        };
    }

    private static string ReadRegistryPath(RegistryHive hive, RegistryView view, string value)
    {
        try
        {
            using (RegistryKey root = RegistryKey.OpenBaseKey(hive, view))
            using (RegistryKey steam = root.OpenSubKey(@"Software\Valve\Steam"))
                return steam == null ? null : steam.GetValue(value) as string;
        }
        catch (SecurityException) { return null; }
        catch (UnauthorizedAccessException) { return null; }
        catch (IOException) { return null; }
    }

    private static string ReadSteamFile(string path)
    {
        try { return File.ReadAllText(path); }
        catch (IOException) { return ""; }
        catch (UnauthorizedAccessException) { return ""; }
    }

    private static string GetSteamValue(string contents, string key)
    {
        return Regex.Match(contents, "\"" + key + "\"\\s+\"([^\"]+)\"").Groups[1].Value;
    }

    private static string FullLibraryPath(string path)
    {
        if (String.IsNullOrWhiteSpace(path))
            return null;
        try
        {
            // Ignore relative paths and app IDs/sizes in the VDF.
            string root = Path.GetPathRoot(path);
            if (String.IsNullOrEmpty(root) || root.Length < 3)
                return null;
            string fullPath = Path.GetFullPath(path);
            return fullPath.Length == root.Length ? fullPath : fullPath.TrimEnd('\\', '/');
        }
        catch (ArgumentException) { return null; }
        catch (NotSupportedException) { return null; }
        catch (PathTooLongException) { return null; }
    }

    internal static string ResolveGameRoot(IEnumerable<string> steamRoots, bool interactive)
    {
        var searched = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var libraries = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string steamPath in steamRoots)
        {
            string steam = FullLibraryPath(steamPath);
            if (steam == null || !searched.Add(steam))
                continue;
            libraries.Add(steam);
            foreach (string config in new[] { @"steamapps\libraryfolders.vdf", @"config\libraryfolders.vdf" })
            {
                string contents = ReadSteamFile(Path.Combine(steam, config));
                // Steam uses "path" in current files and numeric keys in older files.
                foreach (Match entry in Regex.Matches(contents, @"(?im)^[ \t]*""(?:path|[0-9]+)""[ \t]+""([^""\r\n]*)"""))
                {
                    string library = FullLibraryPath(entry.Groups[1].Value.Replace(@"\\", @"\"));
                    if (library != null)
                        libraries.Add(library);
                }
            }
        }

        var installed = new List<string>();
        var supported = new List<string>();
        foreach (string library in libraries)
        {
            string steamApps = Path.Combine(library, "steamapps");
            string manifest = ReadSteamFile(Path.Combine(steamApps, AppManifest));
            string installDir = GetSteamValue(manifest, "installdir");
            if (GetSteamValue(manifest, "appid") != AppId || installDir.Length == 0 ||
                installDir == "." || installDir == ".." || installDir.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                continue;
            string game = Path.Combine(steamApps, "common", installDir);
            if (!File.Exists(Path.Combine(game, GameExecutable)))
                continue;
            installed.Add(game);
            if (IsSupportedBuild(manifest))
                supported.Add(game);
        }

        if (supported.Count == 1)
            return supported[0];
        if (installed.Count == 0)
            throw new InvalidOperationException("Steam 라이브러리에서 Europa Universalis V를 찾지 못했습니다. --game-dir로 설치 폴더를 지정하세요.");
        if (supported.Count == 0)
            throw new InvalidOperationException("지원하는 Steam 빌드는 " + Build + " (" + Branch + ")입니다.\n" +
                String.Join("\n", installed));

        supported.Sort(StringComparer.OrdinalIgnoreCase);
        if (interactive)
        {
            Console.WriteLine("지원 빌드가 설치된 폴더를 선택하세요.");
            for (int i = 0; i < supported.Count; i++)
                Console.WriteLine((i + 1) + ". " + supported[i]);
            Console.Write("> ");
            int index;
            if (Int32.TryParse(Console.ReadLine(), out index) && index >= 1 && index <= supported.Count)
                return supported[index - 1];
            throw new InvalidOperationException("설치 폴더 선택을 취소했습니다.");
        }
        throw new InvalidOperationException("지원 빌드가 여러 폴더에 있습니다. --game-dir로 설치 폴더를 지정하세요.\n" +
            String.Join("\n", supported));
    }

    private static void Run(string mode, string root)
    {
        DirectoryInfo game = new DirectoryInfo(root);
        if (game.Parent == null || game.Parent.Parent == null)
            throw new InvalidOperationException("Steam 게임 설치 폴더를 지정하세요.");

        string manifest = Path.Combine(game.Parent.Parent.FullName, AppManifest);
        string target = Path.Combine(game.FullName, GameExecutable);
        using (SHA256 sha = SHA256.Create())
        using (Mutex mutex = new Mutex(false, @"Local\EU5KoreanIme148-" +
            Hex(sha.ComputeHash(Encoding.UTF8.GetBytes(game.FullName.TrimEnd('\\').ToUpperInvariant())))))
        {
            try
            {
                if (!mutex.WaitOne(0))
                    throw new InvalidOperationException("같은 설치 경로에서 패처가 이미 실행 중입니다.");
            }
            catch (AbandonedMutexException)
            {
                // The previous process exited. Revalidate the installed file before continuing.
            }

            try
            {
                if (mode != "status")
                    RequireGameClosed();

                // Keep Steam's manifest and the source bytes stable until the candidate is ready.
                using (FileStream appState = File.Open(manifest, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (FileStream source = OpenImage(target))
                {
                    CheckBuild(appState);
                    bool patched = CheckImage(source);
                    if (mode == "status")
                    {
                        Console.WriteLine("EU5 1.4.8 테스트 브랜치 / Steam 빌드 " + Build);
                        Console.WriteLine("실행 파일 상태 " + (patched ? "패치 적용됨" : "Steam 원본"));
                        Console.WriteLine(target);
                        return;
                    }

                    bool desired = mode == "apply";
                    if (patched == desired)
                    {
                        Console.WriteLine(desired ? "이미 패치가 적용되어 있습니다." : "이미 Steam 원본입니다.");
                        return;
                    }

                    ReplaceImage(source, target, desired);
                    Console.WriteLine(desired ? "한글 입력 패치 적용과 해시 확인을 완료했습니다."
                                             : "Steam 원본 복원과 해시 확인을 완료했습니다.");
                }
            }
            finally
            {
                mutex.ReleaseMutex();
            }
        }
    }

    private static void CheckBuild(Stream manifest)
    {
        using (StreamReader reader = new StreamReader(manifest, Encoding.UTF8, true, 4096, true))
        {
            if (!IsSupportedBuild(reader.ReadToEnd()))
                throw new InvalidOperationException("지원하는 Steam 빌드는 " + Build + " (" + Branch + ")입니다.");
        }
    }

    private static bool IsSupportedBuild(string contents)
    {
        if (GetSteamValue(contents, "appid") != AppId || GetSteamValue(contents, "buildid") != Build)
            return false;
        MatchCollection branches = Regex.Matches(contents, "\"BetaKey\"\\s+\"([^\"]+)\"");
        foreach (Match branch in branches)
        {
            if (branch.Groups[1].Value != Branch)
                return false;
        }
        return branches.Count > 0;
    }

    private static void RequireGameClosed()
    {
        Process[] games = Process.GetProcessesByName("eu5");
        foreach (Process game in games)
            game.Dispose();
        if (games.Length != 0)
            throw new InvalidOperationException("Europa Universalis V를 완전히 종료한 뒤 적용하거나 복원하세요.");
    }

    private static FileStream OpenImage(string path)
    {
        return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete,
            1024 * 1024, FileOptions.SequentialScan);
    }

    private static bool CheckImage(Stream image)
    {
        if (image.Length != ExeLength)
            throw new InvalidOperationException("eu5.exe 파일 크기가 지원하는 빌드와 다릅니다.");
        image.Position = 0;
        string hash;
        using (SHA256 sha = SHA256.Create())
            hash = Hex(sha.ComputeHash(image));

        if (hash != OriginalHash && hash != PatchedHash)
            throw new InvalidOperationException("eu5.exe SHA-256이 확인된 원본 또는 패치본과 다릅니다.\n" + hash);
        bool patched = hash == PatchedHash;
        byte[] expected = patched ? PatchedBytes : OriginalBytes;
        image.Position = Offset;
        foreach (byte value in expected)
        {
            if (image.ReadByte() != value)
                throw new InvalidOperationException("패치 위치의 6바이트가 일치하지 않습니다.");
        }
        return patched;
    }

    private static void ReplaceImage(Stream source, string target, bool desired)
    {
        // Stage on the same volume, then replace the verified image in one filesystem operation.
        string temp = Path.Combine(Path.GetDirectoryName(target), ".eu5-ime-" + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (FileStream staged = new FileStream(temp, FileMode.CreateNew, FileAccess.ReadWrite,
                FileShare.None, 1024 * 1024, FileOptions.SequentialScan))
            {
                source.Position = 0;
                source.CopyTo(staged, 1024 * 1024);
                staged.Position = Offset;
                byte[] change = desired ? PatchedBytes : OriginalBytes;
                staged.Write(change, 0, change.Length);
                staged.Flush(true);
                if (CheckImage(staged) != desired)
                    throw new InvalidOperationException("교체할 파일이 예상한 상태와 다릅니다.");
            }

            RequireGameClosed();
            File.Replace(temp, target, null);
            using (FileStream installed = OpenImage(target))
            {
                if (CheckImage(installed) != desired)
                    throw new InvalidOperationException("교체 후 실행 파일의 상태가 예상과 다릅니다.");
            }
        }
        finally
        {
            if (File.Exists(temp))
                File.Delete(temp);
        }
    }

    private static string Hex(byte[] value)
    {
        return BitConverter.ToString(value).Replace("-", "").ToLowerInvariant();
    }
}
